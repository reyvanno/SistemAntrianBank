<?php

namespace Database\Seeders;

use App\Models\Counter;
use App\Models\Service;
use Illuminate\Database\Seeder;

class CounterSeeder extends Seeder
{
    public function run(): void
    {
        $teller = Service::where('code', 'A')->firstOrFail();
        $customerService = Service::where('code', 'B')->firstOrFail();

        Counter::upsert(
            [
                [
                    'service_id' => $teller->id,
                    'code' => 'T1',
                    'is_active' => true,
                ],
                [
                    'service_id' => $teller->id,
                    'code' => 'T2',
                    'is_active' => true,
                ],
                [
                    'service_id' => $customerService->id,
                    'code' => 'CS1',
                    'is_active' => true,
                ],
                [
                    'service_id' => $customerService->id,
                    'code' => 'CS2',
                    'is_active' => true,
                ],
            ],
            ['code'],
            [
                'service_id',
                'is_active',
            ]
        );
    }
}