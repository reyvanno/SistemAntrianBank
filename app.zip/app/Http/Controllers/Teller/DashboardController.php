<?php

namespace App\Http\Controllers\Teller;

use App\Http\Controllers\Controller;
use App\Services\TellerService;

class DashboardController extends Controller
{
    public function __construct(
        protected TellerService $tellerService
    ) {
    }

    public function index()
    {
        return inertia(
            'Teller/Dashboard',
            $this->tellerService->dashboard(
                auth()->user()
            )
        );
    }
}