<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreServiceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => [
                'required',
                'string',
                'max:5',
                'unique:services,code',
            ],

            'name' => [
                'required',
                'string',
                'max:255',
            ],
        ];
    }
}
