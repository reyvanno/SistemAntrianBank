<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateServiceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'code' => [

                'required',

                'string',

                'max:5',

                Rule::unique('services')
                    ->ignore($this->service),

            ],

            'name' => [

                'required',

                'string',

                'max:255',

            ],

        ];
    }
}
