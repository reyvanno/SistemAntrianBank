<?php

namespace App\Services;

use App\Models\Queue;
use App\Models\User;

class TellerService
{
    public function dashboard(User $user): array
    {
        $counter = $user->counter;

        $currentQueue = Queue::query()

            ->where('counter_id', $counter->id)

            ->whereIn('status', [
                'CALLED',
                'SERVING',
            ])

            ->latest()

            ->first();

        $waitingQueues = Queue::query()

            ->where('service_id', $counter->service_id)

            ->where('status', 'WAITING')

            ->oldest()

            ->get();

        return [

            'counter' => $counter,

            'currentQueue' => $currentQueue,

            'waitingQueues' => $waitingQueues,

        ];
    }
}