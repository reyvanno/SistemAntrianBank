<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Teller\DashboardController;

Route::middleware([
    'auth',
    'role:teller',
])
    ->prefix('teller')
    ->name('teller.')
    ->group(function () {

        Route::get(
            '/dashboard',
            [DashboardController::class, 'index']
        )->name('dashboard');

        Route::post(
            '/call-next',
            [DashboardController::class, 'callNext']
        )->name('call-next');

        Route::post(
            '/start-service',
            [DashboardController::class, 'startService']
        )->name('start-service');

        Route::post(
            '/finish-service',
            [DashboardController::class, 'finishService']
        )->name('finish-service');

    });