<?php

use Illuminate\Support\Facades\Route;

Route::middleware([
    'auth',
    'role:customer_service',
])
    ->prefix('customer-service')
    ->name('customer_service.')
    ->group(function () {

        Route::get('/dashboard', fn() => inertia('CustomerService/Dashboard'))
            ->name('dashboard');
    });
