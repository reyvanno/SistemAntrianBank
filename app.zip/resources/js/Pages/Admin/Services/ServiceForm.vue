<script setup>
import { useForm } from '@inertiajs/vue3'

const props = defineProps({
    service: {
        type: Object,
        default: () => ({
            code: '',
            name: '',
        }),
    },

    submitRoute: String,
    submitMethod: String,
})

const form = useForm({
    code: props.service.code,
    name: props.service.name,
})

const submit = () => {

    if (props.submitMethod === 'post') {

        form.post(route(props.submitRoute))

        return

    }

    form.put(route(props.submitRoute, props.service.id))

}
</script>

<template>

<form
    @submit.prevent="submit"
    class="space-y-6"
>

    <div>

        <label class="font-medium">

            Kode

        </label>

        <input
            v-model="form.code"
            class="border rounded-lg w-full p-3 mt-2"
        >

        <p
            class="text-red-500 text-sm mt-1"
            v-if="form.errors.code"
        >
            {{ form.errors.code }}
        </p>

    </div>

    <div>

        <label class="font-medium">

            Nama Layanan

        </label>

        <input
            v-model="form.name"
            class="border rounded-lg w-full p-3 mt-2"
        >

        <p
            class="text-red-500 text-sm mt-1"
            v-if="form.errors.name"
        >
            {{ form.errors.name }}
        </p>

    </div>

    <button
        class="bg-indigo-600 text-white px-6 py-3 rounded-lg"
    >

        Simpan

    </button>

</form>

</template>