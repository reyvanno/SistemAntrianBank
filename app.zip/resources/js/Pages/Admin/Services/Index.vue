<script setup>
import AdminLayout from "@/Layouts/AdminLayout.vue";
import { Head, Link, router } from "@inertiajs/vue3";
import { ref, watch } from "vue";
import { usePage } from "@inertiajs/vue3";

const props = defineProps({
    services: Object,
    filters: Object,
});

const destroy = (id) => {
    if (!confirm("Yakin ingin menghapus layanan?")) {
        return;
    }

    router.delete(route("admin.services.destroy", id));
};

const search = ref(props.filters.search ?? "");

watch(search, (value) => {
    router.get(
        route("admin.services.index"),

        {
            search: value,
        },

        {
            preserveState: true,

            replace: true,
        },
    );
});

const page = usePage();
</script>

<template>
    <Head title="Master Service" />

    <AdminLayout>
        <div class="flex justify-between mb-6">
            <h1 class="text-3xl font-bold">Layanan</h1>

            <Link
                :href="route('admin.services.create')"
                class="bg-indigo-600 text-white px-5 py-3 rounded-lg"
            >
                Tambah
            </Link>
        </div>

        <input
            v-model="search"
            placeholder="Cari layanan..."
            class="border rounded-lg px-4 py-3"
        />

        <table class="w-full bg-white rounded-xl overflow-hidden">
            <thead>
                <tr class="border-b">
                    <th class="p-4">Kode</th>

                    <th>Nama</th>

                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <tr
                    v-for="service in services.data"
                    :key="service.id"
                    class="border-b text-center"
                >
                    <td class="p-4">
                        {{ service.code }}
                    </td>

                    <td>
                        {{ service.name }}
                    </td>

                    <td class="text-center">
                        <div class="flex gap-2 justify-center">
                            <Link
                                :href="route('admin.services.edit', service.id)"
                                class="bg-yellow-500 text-white px-4 py-2 rounded"
                            >
                                Edit
                            </Link>
                            <button
                                @click="destroy(service.id)"
                                class="bg-red-500 text-white px-4 py-2 rounded"
                            >
                                Hapus
                            </button>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>

        <div class="flex gap-2 mt-6">
            <Link
                v-for="link in services.links"
                :key="link.label"
                :href="link.url ?? ''"
                v-html="link.label"
                class="border px-4 py-2 rounded"
                :class="{
                    'bg-indigo-600 text-white': link.active,

                    'pointer-events-none opacity-50': !link.url,
                }"
            >
            </Link>
        </div>

        <div
            v-if="page.props.flash.success"
            class="bg-green-100 border border-green-500 text-green-700 rounded-xl p-4 mb-6"
        >
            {{ page.props.flash.success }}
        </div>

        <div
            v-if="page.props.flash.error"
            class="bg-red-100 border border-red-500 text-red-700 rounded-xl p-4 mb-6"
        >
            {{ page.props.flash.error }}
        </div>
    </AdminLayout>
</template>
